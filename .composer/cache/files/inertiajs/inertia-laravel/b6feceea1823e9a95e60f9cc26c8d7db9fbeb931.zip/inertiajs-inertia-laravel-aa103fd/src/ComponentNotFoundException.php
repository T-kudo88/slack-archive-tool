<?php

namespace Inertia;

use InvalidArgumentException;

class ComponentNotFoundException extends InvalidArgumentException {}
